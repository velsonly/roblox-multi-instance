# closes the singleton event so you can run multiple clients

Write-Host ""
Write-Host "=== Roblox Multi-Instance ===" -ForegroundColor Cyan
Write-Host ""

# admin check
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "Not running as admin - you probably want to right-click > Run as Administrator" -ForegroundColor Yellow
    Write-Host ""
}

# find or download handle.exe
$handleExe = Join-Path $PSScriptRoot "handle64.exe"
if (-not (Test-Path $handleExe)) {
    $handleExe = Join-Path $PSScriptRoot "handle.exe"
}

if (-not (Test-Path $handleExe)) {
    Write-Host "handle.exe not found, trying to download it..." -ForegroundColor Yellow
    
    try {
        $zipPath = Join-Path $env:TEMP "handle.zip"
        $extractPath = Join-Path $env:TEMP "handle_extract"
        
        Invoke-WebRequest -Uri "https://download.sysinternals.com/files/Handle.zip" -OutFile $zipPath -UseBasicParsing
        Expand-Archive -Path $zipPath -DestinationPath $extractPath -Force
        
        Copy-Item (Join-Path $extractPath "handle64.exe") (Join-Path $PSScriptRoot "handle.exe")
        
        Remove-Item $zipPath -Force
        Remove-Item $extractPath -Recurse -Force
        
        $handleExe = Join-Path $PSScriptRoot "handle.exe"
        Write-Host "Got it." -ForegroundColor Green
        Write-Host ""
    } catch {
        Write-Host "Couldn't download automatically: $_" -ForegroundColor Red
        Write-Host ""
        Write-Host "Grab it yourself from:" -ForegroundColor Yellow
        Write-Host "https://learn.microsoft.com/en-us/sysinternals/downloads/handle"
        Write-Host "Then drop handle.exe (or handle64.exe) into: $PSScriptRoot"
        Write-Host ""
        pause
        exit
    }
}

Write-Host "Using: $handleExe" -ForegroundColor DarkGray

# suppress the EULA popup
& $handleExe -accepteula | Out-Null 2>&1

Write-Host ""
Write-Host "How to use:" -ForegroundColor Green
Write-Host "  1) Open Roblox, join a game"
Write-Host "  2) Leave this window running"
Write-Host "  3) Launch another Roblox instance"
Write-Host "  4) This script kills the lock so both can run"
Write-Host ""
Write-Host "Watching for Roblox... (Ctrl+C to quit)" -ForegroundColor DarkGray
Write-Host ""

$closedTotal = 0
$lastCount = 0

while ($true) {
    $procs = @(Get-Process -Name "RobloxPlayerBeta" -ErrorAction SilentlyContinue)
    
    if ($procs.Count -gt 0) {
        if ($procs.Count -ne $lastCount) {
            Write-Host "Found $($procs.Count) Roblox process(es)" -ForegroundColor Cyan
            $lastCount = $procs.Count
        }
        
        foreach ($p in $procs) {
            try {
                $raw = & $handleExe -p $p.Id -a -nobanner 2>&1 | Out-String
                $hits = $raw -split "`n" | Where-Object { $_ -match "ROBLOX_singletonEvent" }
                
                foreach ($line in $hits) {
                    if ($line -match "\s+([0-9A-Fa-f]+):\s+Event.*ROBLOX_singletonEvent") {
                        $hid = $matches[1]
                        
                        Write-Host "  Singleton event found (handle $hid, pid $($p.Id)) - closing it..." -ForegroundColor Yellow
                        & $handleExe -c $hid -p $p.Id -y -nobanner 2>&1 | Out-Null
                        Write-Host "  Done - you should be able to open another instance now" -ForegroundColor Green
                        Write-Host ""
                        
                        $closedTotal++
                    }
                }
            } catch {
                Write-Host "  Error checking pid $($p.Id): $_" -ForegroundColor Red
            }
        }
    } else {
        if ($lastCount -gt 0) {
            Write-Host "Roblox closed, waiting..." -ForegroundColor DarkGray
            $lastCount = 0
        }
    }
    
    Start-Sleep -Milliseconds 500
}
