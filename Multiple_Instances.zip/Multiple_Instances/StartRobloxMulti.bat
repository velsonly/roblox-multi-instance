@echo off
title Roblox Multi-Instance
color 0A

powershell.exe -ExecutionPolicy Bypass -NoProfile -File "%~dp0RobloxMulti.ps1"

pause
